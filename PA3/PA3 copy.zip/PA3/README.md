# PA3
## Team Pizza

We were able to implement all features

For while and if statements, we manipulated the visitor in order to insert jump labels in the middle of the node.
Sorry :(

PA3Test1 should not work for this grammar (elseif statement)

MeggyGetPixel does not work as expected, because we could not get working assembly 
from the provided compiler, so we didn't have good resources to base our own generation on.

Our test files are in 'Our Tests'